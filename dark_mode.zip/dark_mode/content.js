// スタイルを適用・削除する関数
function setDarkModeState(isEnabled) {
  let darkStyle = document.getElementById('my-custom-dark-mode-style');
  
  if (isEnabled) {
    if (!darkStyle) {
      darkStyle = document.createElement('style');
      darkStyle.id = 'my-custom-dark-mode-style';
      darkStyle.innerHTML = `
        html {
          filter: invert(100%) hue-rotate(180deg) !important;
          background-color: #111 !important;
        }
        img, video, iframe {
          filter: invert(100%) hue-rotate(180deg) !important;
        }
      `;
      (document.head || document.documentElement).appendChild(darkStyle);
    }
  } else {
    if (darkStyle) {
      darkStyle.remove();
    }
  }
}

// 1. ページ読み込み時にストレージの状態を確認して適用
chrome.storage.local.get(['darkModeEnabled'], (result) => {
  if (result.darkModeEnabled) {
    setDarkModeState(true);
  }
});

// 2. ポップアップ（popup.js）からのメッセージを受け取ってオン/オフ切り替え
chrome.runtime.onMessage.addListener((message) => {
  if (message.action === 'toggle') {
    setDarkModeState(message.enabled);
  }
});